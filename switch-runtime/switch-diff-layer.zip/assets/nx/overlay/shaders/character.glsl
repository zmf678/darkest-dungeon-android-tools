//
// Lit Sprite Shader
//

//
//##Vertex//---------------------------------------------------------------------------------------
//
#version 120
#line ....

// Transform
uniform mat4 modelviewProjection;
uniform mat4 modelview;

// lighting overlay gradient
uniform vec4 GradA;
uniform vec4 GradB;
uniform float YGradientStartLine; 

// wash colour
uniform vec4 Wash;

//lighting RS matrix
uniform mat2 lightmat;

attribute vec3 vPosition;		// vertex in
attribute vec4 vColour;
attribute vec2 vTexcoord;
attribute vec4 vMisc;

varying vec4 sGradient;		// setup (for interpolator) out
varying vec4 sWash;
varying vec4 sColour;
varying vec2 sTexcoord;
varying vec2 sPos;

// Main
void main(void)
{
	// map gradient to -1..1 range
	vec2 gradPos;
	gradPos.x = (vPosition.x - vMisc.x) / (vMisc.y - vMisc.x) * 2.0 - 1.0;
    gradPos.y = ( YGradientStartLine - vPosition.y ) / (YGradientStartLine - 30.0) * 2.0 - 1.0;
	
	// rotate|scale
	gradPos = lightmat * gradPos;

	// map to 0..1 range
	gradPos = gradPos * 0.5 + 0.5;

	sTexcoord	= vTexcoord;
	sWash		= vColour * Wash;
	sColour		= vColour;
	sGradient	= mix( GradA, GradB, gradPos.y );
	sPos		= (modelview * vec4(vPosition, 1.0)).xy;

	gl_Position = modelviewProjection * vec4(vPosition, 1.0);
}
//####

//
//##Fragment//-------------------------------------------------------------------------------------
//
#version 120
#line ....

varying vec4 sGradient;		// setup (interpolated) in
varying vec4 sWash;
varying vec4 sColour;
varying vec2 sTexcoord;
varying vec2 sPos;

varying vec4 fColour;		// fragment out

uniform sampler2D Tex0;
uniform sampler3D TintColourCube;

uniform vec3 BaseLight;
uniform vec3 HalfLight;
uniform vec3 EdgeLight;

uniform vec2 LightRange;

uniform vec3 LightPosition;
uniform vec2 LightFalloffStart;
uniform vec2 LightFalloffDistance;
uniform vec2 OneOverLightFalloffDistanceSqrd;

uniform float Saturation;
uniform float Intensity;
uniform float LightScalar;
uniform float LightFalloffScalar;
uniform float TintColourCubeLerp;

const float lut_size = 16.0;
const vec3 scale = vec3( ( lut_size - 1.0 ) / lut_size );
const vec3 offset = vec3( 1.0 / ( 2.0 * lut_size ) );


const vec2 light_position = vec2( 960.0, 270.0 );


// Photoshop 'Overlay' blend math for a single channel
// FIXME: remove branch, use conditional move instead
float overlayf( float base, float blend )
{
	if( base < 0.5 ) {
		return 2.0 * base * blend;
	}
	else {
		return 1.0 - 2.0 * (1.0 - base) * (1.0 - blend);
	}
}

// ...and for rgb
vec3 overlay( vec3 base, vec3 blend )
{   
	return vec3( overlayf(base.r, blend.r), overlayf(base.g, blend.g), overlayf(base.b, blend.b) );
}


// Main
void main(void)
{
	// Lit texture
	vec4 tex0 = texture2D( Tex0, sTexcoord.st);

    // Remap the colours for the character before
    // any lightning is calculated or any other effects
    // are applied.
    vec3 mapped_colour = texture3D( TintColourCube, scale * tex0.xyz + offset ).rgb * tex0.a;
    tex0.rgb = mix( tex0.rgb, mapped_colour, TintColourCubeLerp );

	// vertex colour
	tex0.rgb *= sColour.rgb;

	// final lighting
    //tex0.rgb *= (d < 0.5) ? spanA : spanB;

    vec2 light_vector = sPos - vec2( LightPosition.x, LightPosition.y );
    vec2 eclipse = vec2( abs( light_vector.x ) - LightFalloffStart.x, abs( light_vector.y ) - LightFalloffStart.y );
    eclipse = clamp( eclipse, vec2( 0.0, 0.0 ), LightFalloffDistance );
    eclipse = eclipse * eclipse * OneOverLightFalloffDistanceSqrd;
    float light_intensity = clamp( 1.0 - ( sqrt( eclipse.x + eclipse.y ) * LightFalloffScalar ), 0.0, 1.0 ) ;
    tex0.rgb *= BaseLight * light_intensity * Intensity * LightScalar;

	// mix lit texture and wash
	gl_FragColor.rgb = mix( tex0.rgb, tex0.rgb * sWash.rgb, sWash.a );
	

	// mix previous result and overlay
	gl_FragColor.a = tex0.a * sColour.a;
    gl_FragColor.rgb *= sColour.a;

}
//####
