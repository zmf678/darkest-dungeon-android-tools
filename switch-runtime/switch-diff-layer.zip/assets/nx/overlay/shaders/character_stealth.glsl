//
// Lit Sprite Shader
//

//
//##Vertex//---------------------------------------------------------------------------------------
//
#version 120
#line ....

// Transform
uniform mat4 modelviewProjection;
uniform mat4 modelview;

// lighting overlay gradient
uniform vec4 GradA;
uniform vec4 GradB;
uniform float YGradientStartLine; 

// wash colour
uniform vec4 Wash;

//lighting RS matrix
uniform mat2 lightmat;

attribute vec3 vPosition;		// vertex in
attribute vec4 vColour;
attribute vec2 vTexcoord;
attribute vec4 vMisc;

varying vec4 sGradient;		// setup (for interpolator) out
varying vec4 sWash;
varying vec4 sColour;
varying vec2 sTexcoord;
varying vec2 sPos;

// Main
void main(void)
{
	// map gradient to -1..1 range
	vec2 gradPos;
	gradPos.x = (vPosition.x - vMisc.x) / (vMisc.y - vMisc.x) * 2.0 - 1.0;
    gradPos.y = ( YGradientStartLine - vPosition.y ) / (YGradientStartLine - 30.0) * 2.0 - 1.0;
	
	// rotate|scale
	gradPos = lightmat * gradPos;

	// map to 0..1 range
	gradPos = gradPos * 0.5 + 0.5;

	sTexcoord	= vTexcoord;
	sWash		= vColour * Wash;
	sColour		= vColour;
	sGradient	= mix( GradA, GradB, gradPos.y );
	sPos		= (modelview * vec4(vPosition, 1.0)).xy;

	gl_Position = modelviewProjection * vec4(vPosition, 1.0);
}
//####

//
//##Fragment//-------------------------------------------------------------------------------------
//
#version 120
#line ....

varying vec4 sGradient;		// setup (interpolated) in
varying vec4 sWash;
varying vec4 sColour;
varying vec2 sTexcoord;
varying vec2 sPos;

varying vec4 fColour;		// fragment out

uniform sampler2D Tex0;
uniform sampler3D TintColourCube;
uniform sampler3D StealthColourGradeDark;
uniform sampler3D StealthColourGradeLight;


uniform float StealthTransition;
uniform vec3 BaseLight;
uniform vec3 HalfLight;
uniform vec3 EdgeLight;

uniform vec2 LightRange;

uniform vec3 LightPosition;
uniform vec2 LightFalloffStart;
uniform vec2 LightFalloffDistance;
uniform vec2 OneOverLightFalloffDistanceSqrd;

uniform float Saturation;
uniform float Intensity;
uniform float LightScalar;
uniform float LightFalloffScalar;
uniform float TintColourCubeLerp;

uniform float TimeInStealth;

const float lut_size = 16.0;
const vec3 scale = vec3( ( lut_size - 1.0 ) / lut_size );
const vec3 offset = vec3( 1.0 / ( 2.0 * lut_size ) );


const vec2 light_position = vec2( 960.0, 270.0 );


// Photoshop 'Overlay' blend math for a single channel
// FIXME: remove branch, use conditional move instead
float overlayf( float base, float blend )
{
	if( base < 0.5 ) {
		return 2.0 * base * blend;
	}
	else {
		return 1.0 - 2.0 * (1.0 - base) * (1.0 - blend);
	}
}

// ...and for rgb
vec3 overlay( vec3 base, vec3 blend )
{   
	return vec3( overlayf(base.r, blend.r), overlayf(base.g, blend.g), overlayf(base.b, blend.b) );
}


// Main
void main(void)
{
	// Lit texture
	vec4 tex0 = texture2D( Tex0, sTexcoord.st );

 //   vec3 test = mix( tex0.rgb, tex1.rgb, -1.0 );
        

//    tex0.rgb = mix( test.rgb, tex2.rgb, 0.5 );

    //tex0.rgb = vec3( 1.0, 1.0, 1.0 );

    // Remap the colours for the character before
    // any lightning is calculated or any other effects
    // are applied.
    vec3 mapped_colour = texture3D( TintColourCube, scale * tex0.xyz + offset ).rgb;
    tex0.rgb = mix( tex0.rgb, mapped_colour, TintColourCubeLerp );


    const float Y_PHASE = 800.0;
    const float ONE_OVER_Y_PHASE = 1.0 / Y_PHASE;
    const float Y_PHASE_TIME = 4.0;
    const float ONE_OVER_Y_PHASE_TIME = 1.0 / Y_PHASE_TIME;
    const float X_PHASE = 200.0;
    const float ONE_OVER_X_PHASE = 1.0 / X_PHASE;
    const float X_PHASE_TIME = 18.0;
    
    const float ONE_OVER_X_PHASE_TIME = 1.0 / X_PHASE_TIME;


    float normalized_y_phase_time = fract( TimeInStealth * ONE_OVER_Y_PHASE_TIME );
    float normalized_y_phase = ( cos( fract( ( sPos.y - normalized_y_phase_time * Y_PHASE ) * ONE_OVER_Y_PHASE ) * 3.141569 * 2.0 ) + 1.0 ) / 2.0;
    

    float normalized_x_phase_time = fract( TimeInStealth * ONE_OVER_X_PHASE_TIME );
    float x_phase = ( cos( fract( ( sPos.x + cos( normalized_x_phase_time * 3.141569 * 2.0 ) * X_PHASE ) / X_PHASE ) * 3.141569 * 2.0 ) + 1.0 ) / 2.0;

    float test = clamp((  normalized_y_phase * x_phase * 1.7 ), .1, 1.0 );


//    float cos_y_intensity = mod( sPos.y, Y_PHASE ) / Y_PHASE + ( cos( mod( TimeInStealth, Y_PHASE_TIME ) / Y_PHASE * 3.141569 * 2 ) );
//    float y_intensity = cos_y_intensity + 1.0 / 2.0;

//    float x_intensity = mod( sPos.x, X_PHASE ) / X_PHASE + ( cos( mod( TimeInStealth * 11.0f, X_PHASE ) / X_PHASE * 3.141569 * 2 ) );
//    x_intensity = ( x_intensity + 1.0 ) / 2.0;

//    float test = clamp( ( y_intensity + x_intensity ) / 2.0, 0.1, 1.0 );
    //float test = y_intensity * x_intensity;


    vec3 stealth_dark = texture3D( StealthColourGradeDark, scale * tex0.xyz + offset ).rgb;
    vec3 stealth_light = texture3D( StealthColourGradeLight, scale * tex0.xyz + offset ).rgb;

    vec3 stealth_blend = mix( stealth_light.rgb, stealth_dark.rgb, test );

    //tex0.rgb = mix( tex0.rgb, mapped_colour, test  );
    tex0.rgb = mix( tex0.rgb, stealth_blend.rgb * tex0.a, StealthTransition );

	// vertex colour
	tex0.rgb *= sColour.rgb;

	// final lighting
    //tex0.rgb *= (d < 0.5) ? spanA : spanB;

    vec2 light_vector = sPos - vec2( LightPosition.x, LightPosition.y );
    vec2 eclipse = vec2( abs( light_vector.x ) - LightFalloffStart.x, abs( light_vector.y ) - LightFalloffStart.y );
    eclipse = clamp( eclipse, vec2( 0.0, 0.0 ), LightFalloffDistance );
    eclipse = eclipse * eclipse * OneOverLightFalloffDistanceSqrd;
    float light_intensity = clamp( 1.0 - ( sqrt( eclipse.x + eclipse.y ) * LightFalloffScalar ), 0.0, 1.0 ) ;
    tex0.rgb *= BaseLight * light_intensity * Intensity * LightScalar;

	// mix lit texture and wash
	gl_FragColor.rgb = mix( tex0.rgb, tex0.rgb * sWash.rgb, sWash.a );
	

	// mix previous result and overlay
	gl_FragColor.a = tex0.a * sColour.a;
    gl_FragColor.rgb *= sColour.a;

}
//####
